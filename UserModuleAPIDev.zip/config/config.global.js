var config = module.exports = {};

config.env = 'undefined';
config.hostname = 'undefined.example.com';
config.sessionSecret = 'mySecretSessionKey';
config.public_key = '50YpksEKv9QuMVwEOS7MfK7f2YrHmZ';
config.private_key = 'U2FsdGVkX1+RAE8xkC+lHVn+retxpncXsdGjNPmYr8Sa+mNSBXkqi0FwEU+wi6Nl';
config.API_URL = 'https://qbrkrz9qz9.execute-api.us-east-1.amazonaws.com/DemoAPIDev';
config.module_name= 'Module2';
config.SALT = '7sd!O(!@$*!#*#!a989!!@*#!@#&!^#*!&3hASD987*(#*%$&';
config.authentication_method = 'POST';
